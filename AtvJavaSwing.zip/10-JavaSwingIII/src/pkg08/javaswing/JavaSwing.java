package pkg08.javaswing;

import java.util.ArrayList;
import model.DaoPaises;
import model.Paises;
import view.PaisesView;

public class JavaSwing {

    
    public static void main(String[] args) {
        DaoPaises daoPaises = new DaoPaises();
        ArrayList<Paises> paises = daoPaises.buscarTodos();
        
        for(Paises p : paises){
            System.out.println(p.getSigla() + " - " + p.getPais());
        } 
        
        //com.formdev.flatlaf.FlatLightLaf.setup();    // Tema Claro
        com.formdev.flatlaf.FlatDarkLaf.setup();     // Tema Escuro
        
        new PaisesView().setVisible(true); //Chama a view 
    }
    
}
