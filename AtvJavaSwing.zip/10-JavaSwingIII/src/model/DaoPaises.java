package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class DaoPaises {
    private Connection conn;
    private Statement st;

    private void conectar(){
        try {
            this.conn = GerenciadorConexao.pegarConexao(); //Puxa a conexão
            this.st = conn.createStatement(); //Statement: objeto que intermedia a conversa com o banco

        } catch (Exception e){
            System.out.println("Erro: " + e.getMessage());
        }
    }

    private void desconectar(){
        try {
            this.st.close(); 
            this.conn.close(); 
        } catch (Exception e){
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public boolean inserir(Paises p){
        boolean resultado = false;

        try {
            this.conectar();
            String comando = "INSERT INTO tbpaises VALUES (" + "Null, '" + p.getPais() +"', '" + p.getSigla() + "', '" + p.getCapital() + "', " + p.getIdioma() + ");";

            //System.out.println(comando);

            st.executeUpdate(comando);
            resultado = true;

        } catch (Exception e) {
            System.out.println("Erro ao inserir registro: " + e.getMessage());
        
        } finally{
            this.desconectar();
        }

        return  resultado;
    }

    public ArrayList<Paises> buscarTodos(){
        ArrayList<Paises> resultados = new ArrayList<>();
        try {
            this.conectar();
            ResultSet rs = st.executeQuery("SELECT * FROM tbpaises ORDER BY pais "); //ResultSet: Armazena os vindo do banco de dados, em formato de tabela.

            while(rs.next()){ //Vai um por um até o proximo ser vazio, não dá null pointer
                Paises p = new Paises(); //Dentro do objeto pais, ele seta os valores seguinda as tabelas do banco de dados.

                p.setCodigo(rs.getInt("codigo"));
                p.setPais(rs.getString("pais")); 
                p.setSigla(rs.getString("sigla"));
                p.setCapital(rs.getString("capital"));
                p.setIdioma(rs.getString("idioma")); 

                resultados.add(p); //Coloca o Objeto P presetado dentro de um arraylist.
            }

        } catch (Exception e) {
            System.out.println("Erro ao buscar os registro: " + e.getMessage());
        
        } finally{
            this.desconectar();
        }

        return resultados;
    }
    
    public ArrayList<Paises> buscarTodosFiltro(String campo, String filtro){
        ArrayList<Paises> resultados = new ArrayList<>();
        
        if(!campo.equals("pais") && !campo.equals("Sigla")){
            return resultados;
        }
        
        
        
        
        try {
            this.conectar();
            ResultSet rs = st.executeQuery("SELECT * FROM tbpaises WHERE " + campo + " LIKE '%" + filtro + "%' ORDER BY pais "); //ResultSet: Armazena os vindo do banco de dados, em formato de tabela.

            while(rs.next()){ //Vai um por um até o proximo ser vazio, não dá null pointer
                Paises p = new Paises(); //Dentro do objeto paises, ele seta os valores seguindo as tabelas do banco de dados.

                p.setCodigo(rs.getInt("codigo"));
                p.setPais(rs.getString("pais")); 
                p.setSigla(rs.getString("sigla"));
                p.setCapital(rs.getString("capital"));
                p.setIdioma(rs.getString("idioma")); 

                resultados.add(p); //Coloca o Objeto P presetado dentro de um arraylist.
            }

        } catch (Exception e) {
            System.out.println("Erro ao buscar os registro: " + e.getMessage());
        
        } finally{
            this.desconectar();
        }

        return resultados;
    }

    public int excluir (int cod){
        int qtde = 0;

        
        try {
            this.conectar();
            String comando = "DELETE FROM tbpaises WHERE codigo = " + cod + ";";
            st.execute(comando);
            
            qtde = st.getUpdateCount();

        } catch (Exception e) {
            System.out.println("Erro ao deletar registro: " + e.getMessage());
        
        } finally{
            this.desconectar();
        }

        return qtde;
    }

    public int alterar(Paises p){
        int qtde = 0;
        try {
            this.conectar();
            String comando = "UPDATE tbpaises SET "
            + "pais = '" + p.getPais() + "', " 
            + "sigla = '" + p.getSigla() + "', " 
            + "capital = '" + p.getCapital() + "', " 
            + "idioma = '" + p.getIdioma() + "' "
            + "WHERE codigo = " + p.getCodigo() + ";";
            
            //System.out.println(comando);

            st.executeUpdate(comando);
            qtde = st.getUpdateCount();

        } catch (Exception e) {
            System.out.println("Erro ao inserir registro: " + e.getMessage());
        
        } finally{
            this.desconectar();
        }

        return qtde;
    } 


}
