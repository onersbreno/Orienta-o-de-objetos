package view;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
import model.Paises;

public class PaisesTableModel extends AbstractTableModel{
    public static final int COL_CODIGO = 0;
    public static final int COL_PAIS = 1;
    public static final int COL_SIGLA = 2;
    public static final int COL_CAPITAL = 3;
    public static final int COL_IDIOMA = 4;

    public ArrayList<Paises> listaPaises;
    
    public PaisesTableModel(ArrayList<Paises> Paises){
        this.listaPaises = Paises;
    
    }
    
    @Override
    public int getColumnCount(){
        return 5;
    }
    
    @Override
    public int getRowCount(){
        return listaPaises.size();
    
    }
    
    @Override
    public String getColumnName(int coluna){
        String nome = "";
        if(coluna == COL_CODIGO){nome = "Codigo";}
        if(coluna == COL_PAIS){nome = "Pais";}
        if(coluna == COL_SIGLA){nome = "Sigla";}
        if(coluna == COL_CAPITAL){nome = "Capital";}
        if(coluna == COL_IDIOMA){nome = "Idioma";}
        return nome;
    }
    
    @Override
    public Object getValueAt(int linha, int coluna){
        Paises p = listaPaises.get(linha);
        Object conteudo = "";
        
        if(coluna == COL_CODIGO){conteudo = p.getCodigo();}
        if(coluna == COL_PAIS){conteudo = p.getPais();}
        if(coluna == COL_SIGLA){conteudo = p.getSigla();}
        if(coluna == COL_CAPITAL){conteudo = p.getCapital();}
        if(coluna == COL_IDIOMA){conteudo = p.getIdioma();}
   
        return conteudo;
    
    
    }
    
    
}
