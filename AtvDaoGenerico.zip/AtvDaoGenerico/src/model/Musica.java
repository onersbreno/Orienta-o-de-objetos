package src.model;

public class Musica
{
    private int id;
    private String titulo;
    private String album;
    private int anoLancamento;
    private int artistaId;

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getTitulo()
    {
        return titulo;
    }

    public void setTitulo(String titulo)
    {
        this.titulo = titulo;
    }

    public String getAlbum()
    {
        return album;
    }

    public void setAlbum(String album)
    {
        this.album = album;
    }

    public int getAnoLancamento()
    {
        return anoLancamento;
    }

    public void setAnoLancamento(int anoLancamento)
    {
        this.anoLancamento = anoLancamento;
    }

    public int getArtistaId()
    {
        return artistaId;
    }

    public void setArtistaId(int artistaId)
    {
        this.artistaId = artistaId;
    }
}
