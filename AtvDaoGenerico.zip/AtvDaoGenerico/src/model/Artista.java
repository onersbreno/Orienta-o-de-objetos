package src.model;

public class Artista {
    private int id;
    private String nome;
    private String generoMusical;

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getNome()
    {
        return nome;
    }

    public void setNome(String nome)
    {
        this.nome = nome;
    }

    public String getGeneroMusical()
    {
        return generoMusical;
    }

    public void setGeneroMusical(String generoMusical)
    {
        this.generoMusical = generoMusical;
    }
}