package src.view;

import java.util.ArrayList;
import java.util.Scanner;

import src.dao.DaoGenerico;
import src.model.Musica;

public class MusicaView {

    private Scanner scanner;
    private DaoGenerico daoGenerico;

    public MusicaView() {
        scanner = new Scanner(System.in);
        daoGenerico = new DaoGenerico();
    }

    public void menu() throws Exception {
        int opcao = 1;
        do {
            limparTela();

            System.out.println("|       Crud Musicas        |");
            System.out.println("-----------------------------");
            System.out.println("| [1] Cadastrar             |");
            System.out.println("| [2] Consultar             |");
            System.out.println("| [3] Alterar               |");
            System.out.println("| [4] Excluir               |");
            System.out.println("| [5] Listar Todos          |");
            System.out.println("| [0] Voltar                |");
            System.out.println("-----------------------------");
            System.out.print("Escolha uma opção: ");

            try {
                opcao = Integer.parseInt(scanner.nextLine());
            } catch (Exception e) {
                System.out.println("Informe um valor inteiro válido.");
                opcao = -1;
            }

            switch (opcao) {
                case 1 -> cadastrar();
                case 2 -> consultar();
                case 3 -> alterar();
                case 4 -> excluir();
                case 5 -> listarTodos();
                case 0 -> System.out.println("Bye...");
                default -> System.out.println("Opção inválida.");
            }
        } while (opcao != 0);
    }

    private void cadastrar() throws Exception {
        try {
            Musica m = new Musica();
            limparTela();

            System.out.println("|         Cadastrar Musica             |");
            System.out.println("----------------------------------------");

            System.out.print("ID: ");
            m.setId(Integer.parseInt(scanner.nextLine()));

            System.out.print("Titulo: ");
            m.setTitulo(scanner.nextLine());

            System.out.print("Album: ");
            m.setAlbum(scanner.nextLine());

            System.out.print("Ano de lancamento: ");
            m.setAnoLancamento(Integer.parseInt(scanner.nextLine()));

            System.out.print("ID do Artista: ");
            m.setArtistaId(Integer.parseInt(scanner.nextLine()));

            Musica existente = daoGenerico.consultar(Musica.class, "id", m.getId());

            if (existente != null) {
                System.out.println("ERRO: Já existe uma música com esse ID.");
                pausa();
                return;
            }

            daoGenerico.inserir(m);
            System.out.println("\nMúsica cadastrada com sucesso!");
            pausa();

        } catch (NumberFormatException e) {
            System.out.println("\nERRO: Digite apenas números válidos.");
            pausa();
        }
    }

    private void consultar() {
        try {
            limparTela();

            System.out.println("|         Consultar Musica             |");
            System.out.println("----------------------------------------");
            System.out.print("ID: ");

            int id = Integer.parseInt(scanner.nextLine());

            Musica m = daoGenerico.consultar(Musica.class, "id", id);

            if (m != null) {
                System.out.println();
                System.out.println("|          Dados da Musica             |");
                System.out.println("----------------------------------------");
                System.out.println(" ID..............: " + m.getId());
                System.out.println(" Título..........: " + m.getTitulo());
                System.out.println(" Álbum...........: " + m.getAlbum());
                System.out.println(" Ano.............: " + m.getAnoLancamento());
                System.out.println(" ID do Artista...: " + m.getArtistaId());

                pausa();
            } else {
                System.out.println("Música não encontrada.");
            }

        } catch (NumberFormatException e) {
            System.out.println("Erro: O ID deve ser um número inteiro.");

        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    private void alterar() {
        try {
            limparTela();

            System.out.println("|          Alterar Musica              |");
            System.out.println("----------------------------------------");
            System.out.println("Deixe em branco para manter o valor.");
            System.out.println();

            System.out.print("ID: ");
            int id = Integer.parseInt(scanner.nextLine());

            Musica m = daoGenerico.consultar(Musica.class, "id", id);

            if (m != null) {

                System.out.print("[Título: " + m.getTitulo() + "] ");
                String titulo = scanner.nextLine();
                if (!titulo.isEmpty()) {
                    m.setTitulo(titulo);
                }

                System.out.print("[Álbum: " + m.getAlbum() + "] ");
                String album = scanner.nextLine();
                if (!album.isEmpty()) {
                    m.setAlbum(album);
                }

                System.out.print("[Ano: " + m.getAnoLancamento() + "] ");
                String ano = scanner.nextLine();
                if (!ano.isEmpty()) {
                    m.setAnoLancamento(Integer.parseInt(ano));
                }

                System.out.print("[ID do Artista: " + m.getArtistaId() + "] ");
                String artistaId = scanner.nextLine();
                if (!artistaId.isEmpty()) {
                    m.setArtistaId(Integer.parseInt(artistaId));
                }

                int qtde = daoGenerico.alterar(m, "id", id);

                if (qtde > 0) {
                    System.out.println("\nMúsica atualizada com sucesso!");
                    pausa();
                } else {
                    System.out.println("Não foi possível atualizar.");
                }

            } else {
                System.out.println("\nMúsica não encontrada.");
                pausa();
            }

        } catch (NumberFormatException e) {
            System.out.println("Erro: Entrada de número inválida ao alterar.");

        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    private void excluir() {
        try {
            limparTela();

            System.out.println("|          Excluir Musica              |");
            System.out.println("----------------------------------------");

            System.out.print("ID: ");
            int id = Integer.parseInt(scanner.nextLine());

            Musica m = daoGenerico.consultar(Musica.class, "id", id);

            if (m == null) {
                System.out.println("\nMúsica não encontrada.");
                pausa();
                return;
            }

            System.out.println();
            System.out.println("Música encontrada:");
            System.out.println("Título: " + m.getTitulo());
            System.out.println("Álbum: " + m.getAlbum());

            System.out.print("\nConfirmar exclusão (S/N): ");
            String resposta = scanner.nextLine();

            if (!resposta.equalsIgnoreCase("S")) {
                System.out.println("\nOperação cancelada.");
                pausa();
                return;
            }

            int qtde = daoGenerico.excluir(Musica.class, "id", id);

            if (qtde > 0) {
                System.out.println("\nMúsica excluída com sucesso!");
            } else {
                System.out.println("\nErro ao excluir a música.");
            }

            pausa();

        } catch (NumberFormatException e) {
            System.out.println("\nERRO: O ID deve ser um número inteiro.");
            pausa();
        } catch (Exception e) {
            System.out.println("\nERRO: " + e.getMessage());
            pausa();
        }
    }

    private void listarTodos() {
        ArrayList<Musica> musicas = daoGenerico.buscarTodos(Musica.class);

        System.out.println("\nMúsicas cadastradas:");

        if (musicas.isEmpty()) {
            System.out.println("Nenhuma música encontrada.");
            return;
        }

        System.out.println();

        System.out.println("+--------------------------------------------------------------------------------------------+");
        System.out.printf("| %-3s | %-25s | %-20s | %-4s | %-12s |\n",
                "ID",
                "TITULO",
                "ALBUM",
                "ANO",
                "ID ARTISTA");

        System.out.println("+--------------------------------------------------------------------------------------------+");

        for (Musica m : musicas) {
            System.out.printf("| %-3d | %-25s | %-20s | %-4d | %-12d |\n",
                    m.getId(),
                    m.getTitulo(),
                    m.getAlbum(),
                    m.getAnoLancamento(),
                    m.getArtistaId());
        }

        System.out.println("+--------------------------------------------------------------------------------------------+");
        System.out.println("Total de registros: " + musicas.size());

        pausa();
    }

    private void limparTela() {
        try {
            new ProcessBuilder("clear").inheritIO().start().waitFor();
        } catch (Exception e) {
            for (int i = 0; i < 40; i++) {
                System.out.println();
            }
        }
    }

    private void pausa() {
        System.out.println();
        System.out.print("Pressione ENTER para continuar...");
        scanner.nextLine();
    }

}