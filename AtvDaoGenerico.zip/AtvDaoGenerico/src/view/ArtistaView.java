package src.view;

import java.util.ArrayList;
import java.util.Scanner;
import src.dao.DaoGenerico;
import src.model.Artista;

public class ArtistaView {

    private Scanner scanner;
    private DaoGenerico daoGenerico;

    public ArtistaView() {
        scanner = new Scanner(System.in);
        daoGenerico = new DaoGenerico();
    }

    public void menu() throws Exception {
        int opcao = 1;
        do {
            limparTela();

            System.out.println("|      --Crud Artistas--      |");
            System.out.println("-----------------------------");
            System.out.println("| [1] Cadastrar             |");
            System.out.println("| [2] Consultar             |");
            System.out.println("| [3] Alterar               |");
            System.out.println("| [4] Excluir               |");
            System.out.println("| [5] Listar Todos          |");
            System.out.println("| [0] Voltar                |");
            System.out.println("-----------------------------");
            System.out.print("Escolha uma opção: ");

            try {
                opcao = Integer.parseInt(scanner.nextLine());
            } catch (Exception e) {
                System.out.println("Informe um valor inteiro válido.");
                opcao = -1;
            }

            switch (opcao) {
                case 1 -> cadastrar();
                case 2 -> consultar();
                case 3 -> alterar();
                case 4 -> excluir();
                case 5 -> listarTodos();
                case 0 -> System.out.println("Bye...");
                default -> System.out.println("Opção inválida.");
            }
        } while (opcao != 0);
    }

    public void cadastrar() throws Exception {
        try {
            Artista a = new Artista();

            limparTela();
            System.out.println("|          Cadastrar Artista          |");
            System.out.println("----------------------------------------");

            System.out.print("ID: ");
            a.setId(Integer.parseInt(scanner.nextLine()));

            System.out.print("Nome: ");
            a.setNome(scanner.nextLine());

            System.out.print("Genero Musical: ");
            a.setGeneroMusical(scanner.nextLine());

            Artista existente = daoGenerico.consultar(Artista.class, "id", a.getId());

            if (existente != null) {
                System.out.println("ERRO: Já existe um artista com esse ID.");
                pausa();
                return;
            }

            daoGenerico.inserir(a);
            System.out.println("\nArtista cadastrado com sucesso!");
            pausa();

        } catch (NumberFormatException e) {
            System.out.println("Erro: Digite apenas um ID válido.");
            pausa();
        }
    }

    public void consultar() {
        try {
            System.out.println("\n- - Consulta de Artista - -");
            System.out.print("ID: ");
            int id = Integer.parseInt(scanner.nextLine());

            Artista a = daoGenerico.consultar(Artista.class, "id", id);

            if (a != null) {
                System.out.println();
                System.out.println("|          Dados do Artista            |");
                System.out.println("----------------------------------------");
                System.out.println(" ID..............: " + a.getId());
                System.out.println(" Nome............: " + a.getNome());
                System.out.println(" Gênero..........: " + a.getGeneroMusical());
                System.out.println("----------------------------------------");
                pausa();
            } else {
                System.out.println("Artista não encontrado.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Erro: O ID deve ser um número inteiro.");
        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public void alterar() {
        try {
            limparTela();
            System.out.println("|           Alterar Artista        |");
            System.out.println("----------------------------------------");
            System.out.println("Deixe em branco para manter o valor.");
            System.out.println();

            System.out.print("ID: ");
            int id = Integer.parseInt(scanner.nextLine());

            Artista a = daoGenerico.consultar(Artista.class, "id", id);

            if (a != null) {
                System.out.print("[Nome: " + a.getNome() + "] ");
                String nome = scanner.nextLine();
                if (!nome.isEmpty()) {
                    a.setNome(nome);
                }

                System.out.print("[Gênero: " + a.getGeneroMusical() + "] ");
                String genero = scanner.nextLine();
                if (!genero.isEmpty()) {
                    a.setGeneroMusical(genero);
                }

                int qtde = daoGenerico.alterar(a, "id", id);

                if (qtde > 0) {
                    System.out.println("\nArtista atualizado com sucesso!");
                    pausa();
                } else {
                    System.out.println("Não foi possível atualizar.");
                }

            } else {
                System.out.println("Artista não encontrado.");
            }

        } catch (NumberFormatException e) {
            System.out.println("Erro: Entrada de número inválida.");
        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public void excluir() throws Exception {
        try {
            limparTela();
            System.out.println("|           Excluir Artista            |");
            System.out.println("----------------------------------------");

            System.out.print("ID: ");
            int id = Integer.parseInt(scanner.nextLine());

            Artista a = daoGenerico.consultar(Artista.class, "id", id);

            if (a != null) {

                System.out.println();
                System.out.println("Artista encontrado:");
                System.out.println("Nome: " + a.getNome());

                System.out.print("\nConfirmar exclusão (S/N): ");
                String resposta = scanner.nextLine();

                if (!resposta.equalsIgnoreCase("S")) {
                    System.out.println("Operação cancelada.");
                    pausa();
                    return;
                }
            }

            int qtde = daoGenerico.excluir(Artista.class, "id", id);

            if (qtde > 0) {
                System.out.println("Excluído com sucesso!");
            } else {
                System.out.println("Erro ao excluir ou registro não encontrado.");
            }

        } catch (NumberFormatException e) {
            System.out.println("Erro: O ID deve ser um número inteiro.");
        }
    }

    public void listarTodos() {
        ArrayList<Artista> artistas = daoGenerico.buscarTodos(Artista.class);

        System.out.println("\nArtistas cadastrados:");

        if (artistas.isEmpty()) {
            System.out.println("Nenhum artista encontrado.");
            return;
        }

        System.out.println();
        System.out.println("+------------------------------------------------+");
        System.out.printf("| %-3s | %-20s | %-18s |\n",
                "ID",
                "NOME",
                "GÊNERO");
        System.out.println("+------------------------------------------------+");

        for (Artista a : artistas) {
            System.out.printf("| %-3d | %-20s | %-18s |\n",
                    a.getId(),
                    a.getNome(),
                    a.getGeneroMusical());
        }

        System.out.println("+------------------------------------------------+");
        System.out.println("Total de registros: " + artistas.size());
        pausa();
    }

    private void limparTela() {
        try {
            new ProcessBuilder("clear").inheritIO().start().waitFor();
        } catch (Exception e) {
            for (int i = 0; i < 40; i++) {
                System.out.println();
            }
        }
    }

    private void pausa() {
        System.out.println();
        System.out.print("Pressione ENTER para continuar...");
        scanner.nextLine();
    }

}