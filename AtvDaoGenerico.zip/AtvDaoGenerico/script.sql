CREATE DATABASE db_catalogo_musicas;

USE db_catalogo_musicas;

CREATE TABLE tb_artistas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    generoMusical VARCHAR(50)
);

CREATE TABLE tb_musicas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100) NOT NULL,
    album VARCHAR(100),
    anoLancamento INT,
    artistaId INT NOT NULL,

    CONSTRAINT fk_musica_artista
        FOREIGN KEY (artistaId)
        REFERENCES tb_artistas(id)
);